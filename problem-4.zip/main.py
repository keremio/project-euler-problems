'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
arr = [0] * 999999
k = 0
for a in range(100,999):
    for b in range(100,999):
        x = a*b
        strx = str(x);
        if (len(strx) == 5):
            if (strx[0] == strx[4] and strx[1] == strx[3]):
                'print(x)'
                arr[k] = x
                k = k +1
        elif (len(strx) == 6): 
            if (strx[0] == strx[5] and strx[1] == strx[4] and strx[2] == strx[3]):
                'print(x)'
                arr[k] = x
                k = k + 1
        else :
            print("")
            

arr.sort()
print(arr[-1])

        
    
                