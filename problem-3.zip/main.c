/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    long long int n=600851475143;
    int i=0;
    int arr[50];
    int k=0;
    int test;
    int z;
    int co=0;
    for(test=0; test<50; test++)
    {
        arr[test] = 0;
    }
    for(i=2; i<n; i++)
    {
        if (n%i == 0)
        {
            arr[k] = i;
            k++;
        }
    }
    for (k=0; k<50; k++)
    {
        //printf("%d ", arr[k]);
    }
    
    for(k=0; k<50; k++)
    {
        if (arr[k] == 0)
        {
        }
        for(z=arr[k]; z>0; z--)
        {
            if(arr[k]%z == 0)
            {
            co++;
            }
        }
    if (co == 2)
    {
        printf("%d ", arr[k]);
    }
    co = 0;
    }
    return 0;
}
