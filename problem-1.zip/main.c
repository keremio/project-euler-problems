/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int x;
    for(x=0; x<1000; x++)
    {
        if(x%3 == 0 || x%5 == 0)
        {
            printf("%d", x);
            printf("\n");
        }
        else{}
    }
}
