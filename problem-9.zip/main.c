#include <stdio.h>
#include <math.h>

int main()
{
     int x,y,z;
     for (x=0; x<500; x++)
     {
     	for (y=0; y<500; y++)
     	{
     		for (z=0; z<500; z++)
     		{
     			if (x + y + z == 1000)
     			{
     				if (pow(x,2) + pow(y,2) == pow(z,2))
     				{
     					printf("%d %d %d", x, y, z);
     					printf("\n");
					}
				}
			}
		}
	 }
}
