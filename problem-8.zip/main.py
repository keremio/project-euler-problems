'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
text = "17386296383936191368493925"
text2 = []
a = len(text)

for x in range(0,a-1):
    pro = int(text[x])*int(text[x+1])
    print(pro)
    text2.append(pro)
print("\n")
text2.sort()
print(text2[-1])

