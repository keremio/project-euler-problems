'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import math
print("enter the base!")
n = int(input())
power = 2**n
strpower = str(power)
length = len(strpower)
sumpow = 0
for x in range (0,length):
    sumpow += int(strpower[x])

print(sumpow)