'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

counter = 0
for k in range (2,10):
    n = k
    while (n>1):
        if (n % 2 == 1):
            n = 3*n + 1
            print(n, end=" ")
            counter = counter + 1
        elif (n % 2 == 0):
            n = n / 2
            print(n, end=" ")
            counter += 1
        else:
            print("")
    print(counter)
    counter = 0