#include <stdio.h>

int main()
{
int n;
int k;
int counter;
for (k=2; k<1999999; k++)
{
    n = k;
    do
	if (n % 2 == 1)
	{
		n = 3*n + 1;
		printf("%d " , n);
		counter++;
	}
	else if (n % 2 == 0)
	{
		n = n / 2;
		printf("%d ", n);
		counter++;
	}
	else {}
	while(n>1);
	printf(" %d", counter);
	counter = 0;
	printf("\n");
}
}
