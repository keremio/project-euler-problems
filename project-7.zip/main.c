#include <stdio.h>

int main()
{
     long long int n;
     long long int k;
     int array[10001];
     int co=0;
     int x=0;
     for (n = 99999999; n>0; n--)
     {
     	for (k = 99999999; k>0; k--)
     	{
     		if (n % k == 0)
     		{
     			co++;
			}
		}
		if (co == 2)
		{
			//printf("%d ", n);
			array[x] = n;
			x++;
		}
		co = 0;
	 }
	 for (x=0; x<10001; x++)
	 {
	 printf("%d\n", array[x]);
     }
}