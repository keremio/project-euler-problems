/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[4][4];
    int k;
    int l;
    for (k=0; k<4; k++)
    {
        for (l=0; l<=k; l++)
        {
        printf("%d %d\n", k, l);
        scanf("%d" , &arr[k][l]);
        }
    }
    for (k=0; k<4; k++)
    {
        for (l=0; l<=k; l++)
        {
            printf("%d ", arr[k][l]);
        }
        printf("\n");
    }
    for (k=2; k>=0; k--)
    {
        for (l=0; l<=k; l++)
        {
            if (arr[k+1][l] > arr[k+1][l+1])
            {
                arr[k][l] += arr[k+1][l];
            }
            else if (arr[k+1][l+1] > arr[k+1][l])
            {
                arr[k][l] += arr[k+1][l+1];
            }
            else {}
        }
 
    }
    printf("%d" , arr[0][0]);
}