/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int fib[1000];
    int n;
    int sum;
    fib[0] = 1;
    fib[1] = 1;
    for(n=2; n<1000; n++)
    {
        fib[n] = fib[n-1] + fib[n-2];
    }
    for (n=0; n<1000; n++)
    {
        if(fib[n]%2 == 1)
        {
            if(fib[n] < 4000000)
            {
            sum += fib[n];
            }
            else {}
        }
        else {}
    }
    printf("%d", sum);
    return 0;
}
