#include <stdio.h>

int main()
{
	int sum=0;
    int n = 2000000;
    int k=0;
    scanf("%d", &n);
    int i;
    int co=0;
    for (n=n; n>0; n--)
    {
        for(i=n; i>0; i--)
        {
            if(n>i)
            {   
                if(n % i == 0)
                {
                    co++;
                }
            }
        }
        //printf("%d has %d components\n", n, co);
        if (co==1)
        {
            printf("%d\n", n);
            sum = sum + n;
        }
        co=0;
    }
    printf("%d", sum);
}
