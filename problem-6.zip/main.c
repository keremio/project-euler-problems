#include <stdio.h>
#include <math.h>
int main()
{
    int n;
    int sq = pow(n,2);
    int sum=0;
    int sqsum=0;
    int sumsq;
    for (n = 1 ; n<101; n++)
    {
    	sqsum += pow(n,2);
	}
	for (n = 1; n < 101; n++)
	{
		sum += n;
	}
	sumsq = pow(sum,2);
	
	printf("%d" , sumsq - sqsum);
    return 0;
}
