'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

row = list(range(1,1000))

row[0] = 4
row[1] = 3
row[2] = 3
row[3] = 5
row[4] = 4
row[5] = 4
row[6] = 3
row[7] = 5
row[8] = 5
row[9] = 4
row[10] = 3
row[100] = 7
sumx = 0
for x in range (1,1000):
    n1 = int (x / 10)
    r1 = x % 10
    n2 = int (x / 100)
    r2 = int(x / 10) % 10
    c = x % 10
    if (x<=10):
        sumx = sumx + int(row[x])
    elif(10<x<100):
        sumx = sumx + int(row[n1]) + int(row[r1])
    elif (x == 100):
        sumx = sumx + int(row[x])
    elif (100 < x <= 999):
        sumx = sumx + int(row[n2]) + int(row[r2]) + int(row[c])
    else:
        print("")
print(sumx)